package com.example.myappmodo

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.InputStreamReader
import com.example.myappmodo.mode1.TestBlock // Замените на правильный путь пакета для tester

fun loadTestBlocks(context: Context): List<TestBlock> {
    // Открываем JSON-файл из папки assets
    val gson = Gson()

    // Замените "your_file.json" на имя вашего JSON-файла в папке assets
    val inputStream = context.assets.open("test_questions.json")
    val inputStreamReader = InputStreamReader(inputStream)

    // Определяем тип для десериализации
    val listType = object : TypeToken<List<TestBlock>>() {}.type
    val testBlocks: List<TestBlock> = gson.fromJson(inputStreamReader, listType)

    // Возвращаем список блоков
    return testBlocks // Исправлено на testBlocks
}