package com.example.myappmodo.mode1

data class TestBlock(
    val name: String,              // Название блока тестов
    val questions: List<Question>   // Список вопросов в этом блоке
)
