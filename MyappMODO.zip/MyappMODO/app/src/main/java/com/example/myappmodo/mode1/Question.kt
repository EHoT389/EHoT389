package com.example.myappmodo.mode1

data class Question(
    val question: String,
    val options: List<String>,
    val correctAnswer: String
)
