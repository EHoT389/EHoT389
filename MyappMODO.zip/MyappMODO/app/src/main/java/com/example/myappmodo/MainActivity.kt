package com.example.myappmodo

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.myappmodo.mode1.Question
import com.example.myappmodo.mode1.TestBlock
import java.io.IOException
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Callback
import okhttp3.Call
import okhttp3.Response
import androidx.compose.foundation.layout.Spacer as Spacer1
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyAppMODOMainScreen()
        }
    }
}

@Composable
fun MyAppMODOMainScreen() {
    var surname by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var startTest by remember { mutableStateOf(false) }
    var testCompleted by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) } // Используем mutableIntStateOf

    if (testCompleted) {
        ResultScreen(score) { sendResultsToTelegram(score) }
    } else if (startTest) {
        val context = LocalContext.current
        val blocks = loadTestBlocks(context) // Передаем контекст
        TestScreen(blocks) { finalScore ->
            score = finalScore
            testCompleted = true
        }
    } else {
        StudentInfoScreen(
            surname = surname,
            name = name,
            onSurnameChange = { surname = it },
            onNameChange = { name = it },
            onStartTest = { startTest = true }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentInfoScreen(
    surname: String,
    name: String,
    onSurnameChange: (String) -> Unit,
    onNameChange: (String) -> Unit,
    onStartTest: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        TextField(
            value = surname,
            onValueChange = onSurnameChange,
            label = { Text("Введите фамилию") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer1(modifier = Modifier.height(8.dp))
        TextField(
            value = name,
            onValueChange = onNameChange,
            label = { Text("Введите имя") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer1(modifier = Modifier.height(16.dp))
        Button(
            onClick = onStartTest,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text("Начать тест")
        }
    }
}

@Composable
fun TestScreen(blocks: List<TestBlock>, onTestComplete: (Int) -> Unit) {
    var currentBlockIndex by remember { mutableStateOf(0) }
    var score by remember { mutableIntStateOf(0) } // Используем mutableIntStateOf
    val currentBlock = blocks.getOrNull(currentBlockIndex)

    if (currentBlock != null) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = currentBlock.name, style = MaterialTheme.typography.titleLarge)

            Spacer1(modifier = Modifier.height(8.dp))

            currentBlock.questions.forEach { question ->
                QuestionItem(question) { isCorrect ->
                    if (isCorrect) score += 1
                }
            }

            Spacer1(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    if (currentBlockIndex < blocks.size - 1) {
                        currentBlockIndex += 1 // Переход к следующему блоку
                    } else {
                        onTestComplete(score) // Завершение теста
                    }
                },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text("Следующий блок")
            }
        }
    } else {
        Text("Тест завершен")
    }
}

@Composable
fun QuestionItem(question: Question, onAnswerSelected: (Boolean) -> Unit) {
    var selectedOption by remember { mutableStateOf<String?>(null) }

    Column {
        Text(question.question)
        question.options.forEach { option ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = (option == selectedOption),
                    onClick = {
                        selectedOption = option
                        onAnswerSelected(option == question.correctAnswer)
                    }
                )
                Text(option)
            }
        }
    }
}

@Composable
fun ResultScreen(score: Int, onSendResults: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Результаты теста", style = MaterialTheme.typography.titleLarge)
        Spacer1(modifier = Modifier.height(16.dp))
        Text("Ваш итоговый балл: $score")
        Spacer1(modifier = Modifier.height(16.dp))

        Button(onClick = onSendResults) {
            Text("Отправить результаты в Telegram")
        }
    }
}

// Функция для загрузки блоков теста
@Composable
fun loadTestBlocks(context: Context): List<TestBlock> {
    // Ваша логика для загрузки блоков теста, используя переданный контекст
    return emptyList() // Верните список блоков
}

fun sendResultsToTelegram(score: Int) {
    val client = OkHttpClient()
    val token = "YOUR_TELEGRAM_BOT_TOKEN" // Замените на свой токен бота
    val chatId = "YOUR_CHAT_ID" // Замените на ваш chat ID
    val message = "Результаты теста: $score"

    val url = "https://api.telegram.org/bot$token/sendMessage?chat_id=$chatId&text=$message"
    val request = Request.Builder().url(url).build()

    client.newCall(request).enqueue(object : Callback {
        override fun onResponse(call: Call, response: Response) {
            if (response.isSuccessful) {
                // Успешная отправка, можно обновить интерфейс
                Toast.makeText(LocalContext.current, "Результаты успешно отправлены!", Toast.LENGTH_SHORT).show()
            } else {
                // Ошибка при отправке
                Toast.makeText(LocalContext.current, "Ошибка при отправке результатов!", Toast.LENGTH_SHORT).show()
            }
        }

        override fun onFailure(call: Call, e: IOException) {
            // Ошибка сети
            Toast.makeText(LocalContext.current, "Ошибка при отправке результатов!", Toast.LENGTH_SHORT).show()
        }
    })
}
