plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android") version "2.0.21" // Используйте последнюю стабильную версию
    id("com.github.ben-manes.versions") version "0.51.0"
    alias(libs.plugins.compose.compiler) apply false
}

android {
    namespace = "com.example.myappmodo"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.myappmodo"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs = freeCompilerArgs + listOf("-Xjvm-default=all")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures {
        viewBinding = false
    }

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }
}

dependencies {
    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.0.21")
    implementation("com.google.code.gson:gson:2.11.0") // Проверьте актуальную версию
    implementation("androidx.appcompat:appcompat:1.7.0") // Обновите до последней версии
    implementation("androidx.compose.material3:material3:1.4.0-alpha02") // Обновите до последней версии
    implementation("androidx.compose.runtime:runtime:1.3.2") // Обновите до последней версии
    implementation("androidx.compose.ui:ui:1.3.2") // Обновите до последней версии
    implementation("androidx.activity:activity-compose:1.6.1") // Убедитесь, что это последняя версия
    implementation("com.squareup.okhttp3:okhttp:4.9.3") // Проверьте актуальную версию
}
